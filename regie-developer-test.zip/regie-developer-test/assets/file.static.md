## Static files

Add the `static` keyword to the filename of any file you place manually in this directory.