import './css/main.css'

// Initialisation code
(() => {
  document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
  const Moonbase = window.Moonbase || {};
})();
